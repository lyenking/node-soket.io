/*jq扩展*/
$.extend({
    loadingStart: function() {
        // $('.progress').show();
    },
    loadingEnd: function() {
        // $('.progress').hide();
    },
    put: function(url, data, callback) {
        $.ajax({
            "url": url,
            "data": data,
            "type": "PUT",
            "success": function(res) {
                callback(res);
            }
        })
    },
    delete: function(url, data, callback) {
        $.ajax({
            "url": url,
            "data": data,
            "type": "DELETE",
            "success": function(res) {
                callback(res);
            }
        })
    }
})