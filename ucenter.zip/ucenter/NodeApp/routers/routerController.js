const Async = require("async");
const Util = require('../util/index');
const Login = require('../model/login');
const Register = require('../model/register');

const U100Query = require("../db/ui100dayDB/excuteQuery.js");
const UKQuery = require("../db/uikitDB/excuteQuery.js");
const UGQuery = require("../db/uigreatDB/excuteQuery.js");
const AccountQuery = require("../db/AccountDB/excuteQuery.js");

function RouterController() {}

RouterController.prototype.login = function (req,res) {

    // 登录操作
        var data = req.body;
        console.log("data",data);
        var a = req.headers['x-forwarded-for'] || req.connection.remoteAddress || req.socket.remoteAddress || req.connection.socket.remoteAddress;

        if(!data.username || !data.password){
            return res.json({error:"参数为空",data:null});
        }

        var md5Pass  = Util.MD5(data.password);

        var sql = "select * from ui_user where username = '"+data.username+"'";
        U100Query(sql,function(er,re){
            console.log(re)
            if(er || !re){
                return res.json({error:er,data:null});
            }

            if(md5Pass != re[0]['password']){
                return res.json({error:"密码错误",data:null});
            }

            //var code = encrypt(JSON.stringify(data),"ui100day");
            var code = Util.encrypt(data.username,"ui100day");
            console.log(code)
            //var decode = decrypt(code,"ui100day");

            var randstr1 = Util.randomString(4);
            var randstr2 = Util.randomString(4);

            var ens = randstr1+code+randstr2;
            console.log(ens)
            var srr = ens.substring(4,ens.length - 4);
            //var decode = decrypt(code,"ui100day");
            var decode = Util.decrypt(srr,"ui100day");
            console.log(decode)

            return res.json({error:null,data:randstr1+code+randstr2});
            //res.writeHead(200, {'content-type': 'text/html'});
            //res.redirect('http://127.0.0.1:3000');
            //res.writeHead(302, {'Location': 'http://127.0.0.1:3000'});
            //res.end("<a src='http://127.0.0.1:3000'>跳转</a>");
        });



}

// 呈递index页面
RouterController.prototype.index = function (req,res,next) {
    var uhost = req.query.uhost;
    console.log(uhost);
    if (uhost) {
        return res.render('index', {uhost: uhost});
    }
    next();
}

module.exports  = new RouterController();


