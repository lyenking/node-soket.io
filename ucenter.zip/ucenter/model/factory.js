
// 错误对象便利构造器
module.exports.error = function (message,code) {
    return {message:message,code:code};
}

// 响应对象便利构造器
module.exports.response = function (error,data) {
    return {error:error,data:data}
}