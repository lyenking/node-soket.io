const AccountDB = require("../db/AccountDB/excuteQuery");
const UGDB = require("../db/uigreatDB/excuteQuery");
const U100DB =  require("../db/ui100dayDB/excuteQuery");
const  Async = require("async");
const Factory = require("./factory");

module.exports.checkIfUserExist = checkIfUserExist;
module.exports.getUsersWithName = getUsersWithName;

// 检查用户是否存在
function checkIfUserExist(username,callback) {
        // 检查用户是否存在,判断 username ,u100_username,ug_username是否存在
    var emailReg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
    var sql = "";
    if(emailReg.test(username)){
        sql = "select * from users where u100_email = '" + username +"' or ug_email = '" + username + "' or email = '" + username + "'"
    }else  {
        sql = "select * from users where u100_username = '" + username +"' or ug_username = '" + username + "' or username = '" + username + "'"
    }
        AccountDB(sql,function (err1,res1) {
            if(err1){
                return callback(Factory.error("sql:检查用户是否存在错误",601),null,null)
            }

            var flag =  res1.length > 0 ? true:false;
            return callback(null,flag,res1);
        } )

}

// 判断用户的类型:是已经合并的用户,还是
function getUserClass(sameUsers) {


}

// 根据用户名或者邮箱获取用户
function getUsersWithName(name,callback) {
    // 验证是不是邮箱
   var emailReg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
   var ug_sql = "";
   var u100_sql = "";
   var uc_sql = "";
   if(emailReg.test(name)){
      ug_sql = "select * from user where email = '" + name + "'";
      u100_sql = "select * from ui_user where email = '" + name + "'";
      uc_sql = "select * from users where email = '" + name + "'";
   }else  {
       ug_sql = "select * from user where nickname = '" + name + "'";
       u100_sql = "select * from ui_user where username = '" + name + "'";
       uc_sql = "select * from users where username = '" + name + "'";
   }

   var querys  = {
        ugUser : function (next) {
           UGDB(ug_sql,function (err,res) {

               if(err){
                   next(err,null);
               }else {
                   res.length > 0?next(null,res[0]):next(null,null);
               }
           })
       },
        u100User :function (next) {
           U100DB(u100_sql,function (err,res) {
               if(err){
                   next(err,null);
               }else {
                   res.length > 0?next(null,res[0]):next(null,null);
               }
           })
       },
        ucUser : function (next) {
           AccountDB(uc_sql,function (err,res) {
               if(err){
                   next(err,null);
               }else {
                   res.length > 0?next(null,res[0]):next(null,null);
               }
           })
       }
   };
   Async.parallel(querys,function (err,res) {
       console.log(err,res);
       callback(err,res);
   })

}
