const AccountDB = require("../db/AccountDB/excuteQuery");
const Async = require("async");
const User = require("./user");
const Factory = require("./factory");

function Login() {

}

Login.prototype.login  = function (data,callback) {
    var  username = data.username;
    var password = data.password;
    var uHost = data.uhost;
    var loginIP = data.loginIP;
    // 判断进行登录的站点
    var host = getUserSite(uHost);
    // 如果请求登录来自其它网站,拒绝登录
    if(host === "known"){
        return callback(Factory.error("unknown site try to login!",404),null);
    }

    User.checkIfUserExist(username,function (error,flag,users) {
        if(error){
            return callback(error,null);
        }
        if( flag === false){
            return callback(Factory.error("用户不存在",602),null);
        }
        // userType = 1: 已登录过一次,进行了重合并,通过验证 username ,password 字段登录
        // userType = -1, 用户名虽然该存在,但是,不属于用户名不属于登录的站点
        // userType = 0, 未进行过重合并整理的用户
        console.log("查询到的 user",users);
        var userType = getUserType(users, username, host);
        if (userType == -1) {
            return callback(Factory.error("用户不存在",602),null);
        } else if (userType == 0) {
            // 未合并用户 ,验证密码后,引导用户合并
            switch (host){
                case "ui100day":{
                    // 使用 ui100day 验证密码
                    AccountDB("select * from users where")
                    break;
                }
                case "uigreat":{
                    // 使用 uigreat 验证密码

                    break;
                }
            }



            return callback(null,{token:null,merge:true});
        }
        // TODO: 根据新用户名和新密码,验证登录


    })

}


// 根据用户名搜索到的用户,判断用户身份为重合并用户 ? 未合并中的优阁用户, 未合并中的 ui100day 用户, 重合并的用户 username 字段才会有值,为整理的旧用户是没有值

function  getUserType(useritems,username,site) {
    var newFlag = false;
    var siteFlag = false;
    var emailReg = /\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*/;
    var isEmail = false;
    if (emailReg.test(username)){
        isEmail = true
    }

    for (var index in useritems){
        var user = useritems[index];
        if(user.username == username || user.email == username){
             newFlag = true
        }else {
            switch (site){
                case "ui100day":{
                    user.u100_username == username || user.u100_email == username? siteFlag = true :null;
                    break;
                }
                case "uigreat":{
                    user.ug_username == username || user.ug_email == username? siteFlag = true:null;
                }
                default:
                    break;
            }

        }
    }

    if(newFlag == true){
        return 1
    }else  if(siteFlag == true){
        return 0
    }else {
        return -1
    }
}

function verifyPassword(username,password,host) {
    switch (host){

    }
}




function u100Login(data,callback) {

}

function uiGreatLogin(data,callback) {

}

function uiKitLogin(data,callback) {

}



function getUserSite(uhost) {
    if(uhost.indexOf("ui100day.com") > 0){
         return "ui100day"
    }else if(uhost.indexOf("uigreat.com") > 0){
        return "uigreat"
    }else if(uhost.indexOf("uikit.me") > 0){
        return "uikit"
    }else {
        return "unknown"
    }
}

module.exports = new Login();