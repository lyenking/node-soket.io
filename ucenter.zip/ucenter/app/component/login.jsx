import React,{ Component,PropTypes } from 'react';



import {userStore} from '../store';



class Login  extends Component {
    constructor(props) {
        super(props);
        this.state = {
            forbidLogin:false,
        }
    }



    componentWillMount() {
        let {uhost} = this.props;
        if(!uhost){
            this.setState({
                forbidLogin:true
            })
        }
        console.log("loginPage",this.props);
    }

    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {

        console.log("loginPage",this.props,nextProps);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {

    }

    componentDidUpdate(prevProps, prevState) {

    }

    componentWillUnmount() {

    }

    handlerLoginIn(){
        let username  = this.refs.username.value;
        let password = this.refs.password.value;

        if(!username || !password){
            return toastr.warning("请输入用户名或密码")
        }
        console.log(username,password)

        // 开始登陆
        let data = {
            username,
            password,
            uhost:this.props.uhost
        }

        $.post("/api/login",data,(res)=>{
            console.log(res);
            if(res.error){
                let code = res.error.code;
                switch (code){
                    case 404 :{
                        toastr.error("客户端未授权");
                        break;
                    }
                    case 601:{
                        toastr.warning("登录出错,请稍后重试,或反馈登录问题");
                        break;
                    }
                    case 602:{
                        toastr.warning("该用户不存在");
                        break;
                    }
                    default:
                        toastr.warning("登录出错,请稍后重试,或反馈登录问题");
                        break
                }

            }else {
                if(res.data.token){
                    //  登录成功,返回授权 token
                }else {
                    // 引导用户进行重合并
                    console.log("合并页面");
                    this.props.agenetShowMargePage(username,password);

                }
            }
        })

    }


    render() {
        let {forbidLogin} = this.state;
        return (<div>
			<div className="title">
				<img src="/images/UG_Logo.png" /><div>优阁</div>
			</div>
			<div className="main-panel">
				<ul className="main-list">
					<li>
						<div className="text-title hidden-xs" >用户名/邮箱</div>
						<input type="text" placeholder="请输入用户名或邮箱" ref={"username"} disabled={forbidLogin}/>
					</li>
					<li>
						<div className="text-title hidden-xs" >密码</div>
						<input type="text" placeholder="请输入密码" ref={"password"} disabled={forbidLogin}/>
					</li>
				</ul>
				<div className="main-function row">
					<div className="forget col-xs-12 col-sm-3 col-sm-push-9"><a href="forget.html">忘记密码</a></div>
					<div className="col-xs-12 col-sm-4 col-sm-pull-3"><button onClick={this.handlerLoginIn.bind(this)} disabled={forbidLogin}>登录</button></div>
					<div className="register col-xs-12 col-sm-5">没有账号？<a href="register.html">马上注册</a></div>
				</div>
			</div>
		</div>)
    }
}

export default Login






