import React,{ Component,PropTypes } from 'react';



import {userStore} from '../store';


class MergePage  extends Component {
    constructor(props) {
        super(props);
        this.state = {
             sameUsers:null
        }
    }



    componentWillMount() {

        this.getMergeUsers()

    }

    componentDidMount() {
        console.log("did",this.props)
    }

    componentWillReceiveProps(nextProps) {
        console.log("next",nextProps);
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {

    }

    componentDidUpdate(prevProps, prevState) {

    }

    componentWillUnmount() {

    }


    // 获取绑定用户
    getMergeUsers(){
        let {username,password,uhost} = this.props;
        let data = {
            type:"same-user",
            username:username
        }





    render() {
        let {sameUsers}  = this.state;
        let sameUserView = <span></span>

        return (<div>
                <text>尊敬的用户,优阁用户中心上线了! </text>
                <text>为了更加方便用户使用 UIGreat.com,UI100Day.com,UIKit.me ,我们将三个网站的账号系统整合为"优阁用户中心",通过"优阁用户中心",您仅需要一个账号,就可以登录优阁旗下的所有产品</text>
            <text>下面跟随我们的引导,完成对您已有账号的绑定吧!</text>
            {sameUserView}

    </div>)
    }
}

export default MergePage






