

class UserStore {
	constructor(){
		this.data = {
			userInfo:null,
			isLogin:false
		}
	}
	getData(){
		return this.data;
	}
	setData(data, callback){
		this.data = {
			userInfo:data,
			isLogin:true
		};
		callback();
	}
}


export default new UserStore()