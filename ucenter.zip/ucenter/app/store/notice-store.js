

class NoticeStore {
	constructor(){
		this.data = {
			isNew:false,
			notice:[]
		}
	}
	getData(){
		return this.data;
	}
	setData(data, callback){
		this.data = data;
		callback();
	}
}


export default new NoticeStore()