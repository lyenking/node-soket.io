

class WorkStore {
	constructor(){
		this.data = {};
	}
	getData(id){
		if(id){
			return this.data[id];
		}else{

		}
	}
	setData(data, callback){
		for(var i=0; i<data.length; i++){
			if(data.length !== 1){
				if(i==0){
					data[i].prevId = data[data.length-1].id;
					data[i].nextId = data[i+1].id;
				}else if(i==data.length-1){
					data[i].prevId = data[i-1].id;
					data[i].nextId = data[0].id;
				}else{
					data[i].prevId = data[i-1].id;
					data[i].nextId = data[i+1].id;
				}
			}else{
				data[i].prevId = data[i].id;
				data[i].nextId = data[i].id;
			}
			this.data[data[i].id] = data[i];
		}
		callback();
	}
	upData(id, data, callback){
		this.data[id] = data;
		callback&&callback();
	}
}


export default new WorkStore()