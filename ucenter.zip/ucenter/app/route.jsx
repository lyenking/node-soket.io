import React from 'react';
import { render } from 'react-dom';
import { Route, IndexRoute, RouterContext, Redirect,browserHistory} from 'react-router';

/*Components*/


import App from './App.jsx';
import Index from './controller/Index.jsx';
import Register from "./controller/Register.jsx"



export default (
			<Route history={browserHistory} >

				<Route path="/" component={App}>
					<IndexRoute component={Index}/>
				</Route>
				<Route path="/login" component={Index}/>
				<Route path="/register" component={Register}/>


			</Route>
				)