import React, {Component, PropTypes} from 'react'

class Register extends Component {
    constructor(props) {
        console.log('constructor');
        super(props);
        this.state = {}
    }

    componentWillMount() {
        console.log('componentWillMount');
    }

    componentDidMount() {
        console.log('componentDidMount');
    }

    componentWillReceiveProps(nextProps) {
        console.log('componentWillReceiveProps');
    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {
        console.log('componentWillUpdate');
    }

    componentDidUpdate(prevProps, prevState) {
        console.log('componentDidUpdate');
    }

    componentWillUnmount() {
        console.log('componentWillUnmount');
    }


    render() {
        return <div>
            <div className="title">
                <img src="/images/UG_Logo.png" alt="" /><div>优阁</div>
            </div>
            <div className="main-panel">
                <ul className="main-list">
                    <li>
                        <div className="text-title hidden-xs">用户名</div>
                        <input type="text" placeholder="请输入用户名" />
                    </li>
                    <li>
                        <div className="text-title hidden-xs">邮箱</div>
                        <input type="text" placeholder="请输入邮箱" />
                    </li>
                    <li>
                        <div className="text-title hidden-xs">密码</div>
                        <input type="text" placeholder="请输入密码" />
                    </li>
                    <li>
                        <div className="text-title hidden-xs">确认密码</div>
                        <input type="text" placeholder="请输入确认密码" />
                    </li>
                </ul>
                <div className="main-function row">
                    <div className="col-xs-12"><button>注册</button></div>
                    <div className="register col-xs-12">有账号？<a href="login.html">马上登录</a></div>
                </div>
            </div>
        </div>
    }
}

export default Register





