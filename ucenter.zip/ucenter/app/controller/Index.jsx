import React,{ Component,PropTypes } from 'react';

import Login from "../component/login.jsx";
import MergePage from  "../component/mergePage.jsx";


import {userStore} from '../store';


class Index  extends Component {
    constructor(props) {
        super(props);
        this.state = {
            forbidLogin:false,
            showMerge:false
        }
    }



    componentWillMount() {
        this.uhost = this.props.location.query.uhost;
        console.log(this.uhost);
        if(!this.uhost){
            toastr.error("拒绝访问");
            this.setState({
                forbidLogin:true
            })


        }
    }

    componentDidMount() {

    }

    componentWillReceiveProps(nextProps) {

    }

    shouldComponentUpdate(nextProps, nextState) {
        return true;
    }

    componentWillUpdate(nextProps, nextState) {

    }

    componentDidUpdate(prevProps, prevState) {

    }

    componentWillUnmount() {

    }

    handlerLoginIn(){
        let username  = this.refs.username.value;
        let password = this.refs.password.value;

        if(!username || !password){
            return toastr.warning("请输入用户名或密码")
        }
        console.log(username,password)

        // 开始登陆
        let data = {
            username,
            password,
            uhost:this.uhost
        }

        $.post("/api/login",data,(res)=>{
            if(res.error){
                let code = res.error.code;
                switch (code){
                    case 404 :{
                        toastr.error("客户端未授权");
                        break;
                    }
                    case 601:{
                        toastr.warning("登录出错,请稍后重试,或反馈登录问题");
                        break;
                    }
                    case 602:{
                        toastr.warning("该用户不存在");
                        break;
                    }
                    default:
                        toastr.warning("登录出错,请稍后重试,或反馈登录问题");
                        break
                }

            }else {
                if(res.data.token){
                    //  登录成功,返回授权 token
                }else {
                    // 引导用户进行重合并
                    this.username = username;
                    this.password = password;
                    this.uhost = password;
                    this.setState({
                        showMerge:true
                    })

                }
            }
        })

    }

    handlerShowMarge(name,password){
        this.username = name;
        this.password = password;
        this.setState({
            showMerge: true
        })
    }


    render() {
        let {forbidLogin,showMerge} = this.state;

        let contentView = <span></span>
        console.log("合并页面111")
        if(showMerge){
            contentView = <MergePage username={this.username} password={this.password} uhost={this.uhost}/>
        }else {
            contentView = <Login agenetShowMargePage = {this.handlerShowMarge.bind(this)} uhost={this.uhost}/>
        }

        return (<div>
            {contentView};
        </div>)
    }
}

export default Index






