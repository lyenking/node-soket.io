const U100Query = require("../db/ui100dayDB/excuteQuery.js");
const UKQuery = require("../db/uikitDB/excuteQuery.js");
const UGQuery = require("../db/uigreatDB/excuteQuery.js");
const TestQuery = require("../db/testDB/excuteQuery.js");
const Async = require("async");


function TestRouter() {

}

TestRouter.prototype.test = function (req, res) {

    UGQuery("select  nickname,password,email,qq_bind.unionid from user left join qq_bind  on qq_bind.uid = user.id  ", function (sqlErr, sqlRes) {
        console.log(sqlErr, sqlRes);
        console.log("人数",sqlRes.length);
        if (sqlErr) {
            return res.json({error: sqlErr, data: null});
        }
        var count = 0
        for (var index in sqlRes) {
            var user = sqlRes[index];
            if(user.email && user.email.indexOf("@edusoho.net") > 0){
                // console.log(sqlRes.length,user.email);
                continue;
            }
            var ugSql = "insert into users (ug_username,ug_password,ug_qq,ug_email) values ('" + user.nickname + "','" + user.password + "','" + user.unionid + "','" + user.email + "')";
            ++count;
            TestQuery(ugSql, function (s_err, s_res) {
                console.log(s_err, s_res);
            })
        }
        console.log("个数",count);

         res.json({error: sqlErr, data: null});
    });
};


// 插入UI100Day用户
function insertUI100Users() {
    U100Query("select  username,password,email,ui_oauth.unionid from ui_user left join ui_oauth  on ui_oauth.uid = ui_user.id  ", function (sqlErr, sqlRes) {
        console.log(sqlErr, sqlRes);

        if (sqlErr) {
            return res.json({error: sqlErr, data: null});
        }

        for (var index in sqlRes) {
            var user = sqlRes[index];
            var u100Sql = "insert into users (u100_username,u100_password,u100_qq,u100_email) values ('" + user.username + "','" + user.password + "','" + user.unionid + "','" + user.email + "')";

            TestQuery(u100Sql, function (s_err, s_res) {
                console.log(s_err, s_res);
            })
        }

        res.json({error: sqlErr, data: null});
    });
}

module.exports = new TestRouter();
