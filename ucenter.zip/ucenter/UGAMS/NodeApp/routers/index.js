var express = require('express');
var router = express.Router();
var TestRouter = require("./testRouter.js");


router.get('/api/test',TestRouter.test.bind(TestRouter));


module.exports = router;