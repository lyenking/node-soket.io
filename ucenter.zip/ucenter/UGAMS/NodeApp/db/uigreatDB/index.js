var mysql  = require('mysql');  //调用MySQL模块
//创建一个connection
var DB = mysql.createConnection({
    host     : '101.200.180.217',       //主机
	user     : 'root',    //MySQL认证用户名
    password : '#@HGjh54!me', //MySQL认证用户密码
	port	 : '3306',  //端口号
	database :'neweduuigreat'
});

//创建一个connection
DB.connect(function(err){
	if(err){       
		console.log('[UIGreatDB query] - :'+err);
		return;
	}
	console.log('UIGreatDB:[connection connect]  succeed!');
}); 

module.exports = DB;