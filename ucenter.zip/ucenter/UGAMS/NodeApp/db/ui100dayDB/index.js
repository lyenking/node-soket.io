var mysql  = require('mysql');  //调用MySQL模块
//创建一个connection
var DB = mysql.createConnection({
    host     : '123.207.139.100',       //主机
	user     : 'root',    //MySQL认证用户名
    password : '6bvYFCggGBJzHaFWAcpDJkmm', //MySQL认证用户密码
	port	 : '3306',  //端口号
	database :'ui100day'
});

//创建一个connection
DB.connect(function(err){
	if(err){       
		console.log('[ui100dayDB query] - :'+err);
		return;
	}
	console.log('ui100dayDB:[connection connect]  succeed!');
}); 

module.exports = DB;