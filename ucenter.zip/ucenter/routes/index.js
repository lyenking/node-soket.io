const express = require('express');
const router = express.Router();
const RC = require("./routerController.js");
const Test = require("./testRouter");


// router.get('/api/test',TestRouter.handlerUsers.bind(TestRouter));
// router.get("/api/checksame",Test.checkSameUsername.bind(Test));
// 登录
router.post('/api/login',RC.login.bind(RC));



// 测试 js 与 php base64
router.get("/test/base64",Test.testBase64.bind(Test));
router.get("/test/debase64",Test.testdeBase64.bind(Test));


//
router.post("/api/user",RC.handlerUser.bind(RC));


// 测试 uikit index-html
router.get('/test/uikit',function(req, res){
    return res.render('uikit');
});

// 测试登录 uikit
router.post("/test/login_uikit",Test.testLogin_uikit.bind(Test));

// 测试登录 uigreat
router.post("/test/login_uigreat",Test.testLogin_uigreat.bind(Test));

router.post("/test/post",Test.testpost.bind(Test));

// test uigreat-html
router.get('/test/uigreat',function(req,res){
    return res.render("uigreat");
});


// test sk
router.get('/test/sk',function(req,res){
    return res.render("testsk");
});

// test sk
router.get('/test/sk2',function(req,res){
    return res.render("testsk2");
});



// test sk return data
router.get('/test/resdb',Test.resdb.bind(Test));


// 首页
router.get('/*',RC.index.bind(RC));


module.exports = router;