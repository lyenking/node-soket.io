const U100Query = require("../db/ui100dayDB/excuteQuery.js");
const UKQuery = require("../db/uikitDB/excuteQuery.js");
const UGQuery = require("../db/uigreatDB/excuteQuery.js");
const AccountQuery = require("../db/AccountDB/excuteQuery.js");
const Util = require('../util/index');
var request = require('request');



function TestRouter() {

}

TestRouter.prototype.checkSameUsername = function (req,re) {

    AccountQuery("SELECT * FROM `ug_account_manager`.`users` WHERE `ug_username` IS NOT NULL AND `merge_mark` = '0' ",function (err,res) {

        AccountQuery("SELECT * FROM `ug_account_manager`.`users` WHERE `u100_username` IS NOT NULL AND `merge_mark` = '0'",function (err1,res1) {
            var count = 0;
            var temp = [];
            var ugsql = "select * from users where nickname = ' ****' "
            var u100sql = "select * from ui_user where username = '*****' "
            for(var i in res){
               var uguser = res[i];
                for (var index in res1 ) {
                    var u100user = res1[index];
                    if(uguser.ug_username == u100user.u100_username){
                        count++;
                        console.log("重复的用户",uguser.id,u100user.id,uguser.ug_username);
                        var ug = {
                            username:uguser.ug_username,
                            qq:uguser.ug_qq,
                            email:uguser.ug_email
                        };
                        var u100 = {
                            username:u100user.u100_username,
                            qq:u100user.u100_qq,
                            email:u100user.u100_email

                        }
                        var te = {
                            UG:ug,
                            U100:u100
                        }
                        ugsql  = ugsql + " or nickname = '" + uguser.ug_username + "' ";
                        u100sql = u100sql + " or username = '" + u100user.u100_username + "' ";
                        temp.push(te);

                    }
                }
            }

            re.json({users:temp,Count:count,UGSQL:ugsql,U100SQL:u100sql});
        })

    })


}

// 进行数据迁移使用
TestRouter.prototype.handlerUsers = function (req, res) {
    // 第一步，导入100day用户
    // insertUI100Users(req,res)
    // 第二步，导入优阁用户
    // insertUIGreatUsers(req,res);
    // 第三步：将qq为null的置为NULL
    // nullStringToNULL(req,res)
    // 第四步：将qq相同的账号合并
    // mergeUserWithQQ(req,res)
    // 第五步：将邮箱为空，为null字符串的，置为NULL
    // emptyToNULLWithEmail(req,res);
    // 第六步：将邮箱相同的账号合并
    // mergeUserWithEmail(req,res);
};

TestRouter.prototype.testBase64 = function(req, res){
    var str = req.query;
    console.log(str.code)
    var sEncoded=Util.base64encode(Util.utf16to8(str.code));
    //var sEncoded=Util.base64encode(Util.utf16to8(str.code));
    return res.json({error:null,data:sEncoded});
}

TestRouter.prototype.testdeBase64 = function(req, res){
    var str = req.query;
    console.log(str.code)
    var sEncoded=Util.base64decode(str.code);

    return res.json({error:null,data:sEncoded});
}


TestRouter.prototype.testLogin_uikit = function(req, res){
    var data = req.body;
    if(!data){
        return res.json({error:"参数为空",data:null});
    }

    var md5Pass  = Util.MD5(data.password);

    var sql = "select * from aixiazai_user where username = '"+data.username+"'";
    UKQuery(sql,function(er,re){
        if(er){
            return res.json({error:"error",data:""});
        }

        if(md5Pass != re[0].password){
            return res.json({error:"密码错误",data:""});
        }
        var tik = Util.randomString(5);
        var remdstr = Util.randomString(5);
        var sEncoded=Util.base64encode(Util.utf16to8(data.username));
        console.log(sEncoded)
        return res.json({error:" ",data:tik+sEncoded+remdstr});

    });
};


TestRouter.prototype.testLogin_uigreat = function(req, res){
    var data = req.body;
    if(!data){
        return res.json({error:"参数为空",data:null});
    }

    //var md5Pass  = Util.MD5(data.password);

    var sql = "select * from user where nickname='"+data.username+"'";
    UGQuery(sql,function(er,re){
        if(er){
            return res.json({error:"error",data:""});
        }

        /*
        if(md5Pass != re[0].password){
            return res.json({error:"密码错误",data:""});
        }*/
        var tik = Util.randomString(5);
        var tik2 = Util.randomString(5);
        var remdstr = Util.randomString(5);
        var remdstr2 = Util.randomString(5);
        var un=Util.base64encode(Util.utf16to8(data.username));
        var pwd=Util.base64encode(Util.utf16to8(data.password));
        console.log(un);
        console.log(pwd);

        // 加密参数设置安全机制，带上token验证，头部设置token，ip验证，禁止代理,再加上时间戳，不能超过1分钟

        return res.json({error:" ",data:tik+un+remdstr+"_$"+tik2+pwd+remdstr2});

    });
};

TestRouter.prototype.testpost = function(req, res){
    var dd = req.body;
    //var dd = req.query;
    console.log(dd)
    //return res.json({error:" ",data:dd});

    //return res.json({error:" ",data:dd});
    request.post('http://www.ug.com/register/testpost',{form:{_password:dd.password,_username:dd.username}}, function (error, response, body) {
        console.log('error:', error); // Print the error if one occurred
        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
        console.log('body:', body); // Print the HTML for the Google homepage.
        return res.json({error:" ",data:body});
    });
};

TestRouter.prototype.resdb = function(req, res){
    var sql = "select * from ui_user where id = 1";
    U100Query(sql, function(er,re){
        return res.json({error:er,data:re});
    });
};


module.exports = new TestRouter();


/*
*     私有函数
* */

// 插入uigreat用户
function insertUIGreatUsers(req,res) {
    UGQuery("select  nickname,password,email,qq_bind.unionid from user left join qq_bind  on qq_bind.uid = user.id  ", function (sqlErr, sqlRes) {
        console.log(sqlErr, sqlRes);
        console.log("人数",sqlRes.length);
        if (sqlErr) {
            return res.json({error: sqlErr, data: null});
        }
        var count = 0
        for (var index in sqlRes) {
            var user = sqlRes[index];
            if(user.email && user.email.indexOf("@edusoho.net") > 0){
                // console.log(sqlRes.length,user.email);
                continue;
            }
            var ugSql = "insert into users (ug_username,ug_password,ug_qq,ug_email) values ('" + user.nickname + "','" + user.password + "','" + user.unionid + "','" + user.email + "')";
            ++count;
            AccountQuery(ugSql, function (s_err, s_res) {
                console.log(s_err, s_res);
            })
        }
        console.log("个数",count);

        res.json({error: sqlErr, data: null});
    });
}

// 插入UI100Day用户
function insertUI100Users(req,res) {
    U100Query("select  username,password,email,ui_oauth.unionid from ui_user left join ui_oauth  on ui_oauth.uid = ui_user.id  ", function (sqlErr, sqlRes) {
        console.log(sqlErr, sqlRes);

        if (sqlErr) {
            return res.json({error: sqlErr, data: null});
        }

        for (var index in sqlRes) {
            var user = sqlRes[index];
            var u100Sql = "insert into users (u100_username,u100_password,u100_qq,u100_email) values ('" + user.username + "','" + user.password + "','" + user.unionid + "','" + user.email + "')";

            AccountQuery(u100Sql, function (s_err, s_res) {
                console.log(s_err, s_res);
            })
        }

        res.json({error: sqlErr, data: null});
    });
}
// 将qq 为null字符串的置为NULL
function nullStringToNULL(req,res) {
    AccountQuery("update  users set u100_qq = NULL where u100_qq = 'null'",function (upErr,upRes) {
        AccountQuery("update  users set ug_qq = NULL where ug_qq = 'null'",function (upUGErr,upUGRes) {
            res.json({error:[upErr,upUGErr],result:[upRes,upUGRes]});
        })
    })
}
// 将qq相同的账号合并
function mergeUserWithQQ(req,res) {
    AccountQuery("SELECT * FROM `ug_account_manager`.`users` WHERE `ug_qq` IS NOT NULL OR `u100_qq` IS NOT NULL order by id ",function (qqErr,qqRes) {

        if(qqErr){
            return res.json({error:qqErr,data:null});
        }



        var u100Users = [];
        var ugUsers = [];
        for (var index in qqRes){
            var user = qqRes[index];
            if(user.u100_qq == null){
                ugUsers.push(user);
            }else {
                u100Users.push(user);
            }
        }

        var count = 0
        for (var i in u100Users){
            var u100User = u100Users[i];
            for(var n in ugUsers){
                var uguser = ugUsers[n];
                if(u100User.u100_qq == uguser.ug_qq){
                    count++;
                    AccountQuery("update users set ug_username = '" + uguser.ug_username+ "',  ug_qq = '" + uguser.ug_qq+ "',ug_email = '" + uguser.ug_email + "',ug_password = '" + uguser.ug_password + "'  where id = " + u100User.id,function (m_err,m_res) {
                        if(m_err){
                            console.log("更新失败",u100User.id,uguser.id);
                        }else {
                            AccountQuery("delete from users where id = " + uguser.id,function (d_err,d_res) {
                                console.log("删除：",d_err,uguser.id);
                            })
                        }


                    }  )
                }
            }
        }

        return res.json({error:null,ugNum:ugUsers.length,u100Num:u100Users.length,total:qqRes.length,count:count});

    })


};
// 将邮箱相同的账号合并
function mergeUserWithEmail(req,res) {
    AccountQuery("SELECT * FROM `ug_account_manager`.`users` WHERE `ug_email` IS NOT NULL OR `u100_email` IS NOT NULL order by id ",function (qqErr,qqRes) {

        if(qqErr){
            return res.json({error:qqErr,data:null});
        }



        var u100Users = [];
        var ugUsers = [];
        for (var index in qqRes){
            var user = qqRes[index];
            if(user.u100_email == null){
                ugUsers.push(user);
            }else {
                u100Users.push(user);
            }
        }

        var count = 0
        for (var i in u100Users){
            var u100User = u100Users[i];
            for(var n in ugUsers){
                var uguser = ugUsers[n];
                if(u100User.u100_email == uguser.ug_email){
                    count++;
                    AccountQuery("update users set ug_username = '" + uguser.ug_username+ "',  ug_qq = '" + uguser.ug_qq+ "',ug_email = '" + uguser.ug_email + "',ug_password = '" + uguser.ug_password + "'  where id = " + u100User.id,function (m_err,m_res) {
                        if(m_err){
                            console.log("更新失败",u100User.id,uguser.id);
                        }else {
                            AccountQuery("delete from users where id = " + uguser.id,function (d_err,d_res) {
                                console.log("删除：",d_err,uguser.id);
                            })
                        }


                    }  )
                }
            }
        }

        return res.json({error:null,ugNum:ugUsers.length,u100Num:u100Users.length,total:qqRes.length,count:count});

    })


};
// 将邮箱为空字符，或者‘null’字符的置为NULL
function emptyToNULLWithEmail(req,res) {
    AccountQuery("UPDATE `ug_account_manager`.`users` set u100_email = NULL WHERE `u100_email` = '' OR `u100_email` = 'null'",function (u100_err,u100_res) {
        AccountQuery("UPDATE `ug_account_manager`.`users` set ug_email = NULL WHERE `ug_email` = '' OR `ug_email` = 'null'",function (ug_err,ug_res) {
            res.json({error:[u100_err,ug_err],result:[u100_res,ug_res]});
        })
    })
}




//var str = '严';
//var sEncoded=base64encode(utf16to8(str));
//console.log(sEncoded);



