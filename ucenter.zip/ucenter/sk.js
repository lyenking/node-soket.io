/**
 * Created by UIGreat on 2017/10/7.
 */
var app = require('express')();
var http = require('http').Server(app);
var io = require('socket.io')(http);
var request = require('request');
var deviceTime;
var U100Query = require("./db/ui100dayDB/excuteQuery.js");

function clock(){}
clock.prototype={
    constructor:clock,
    showTime:function(num,callback){
        if(!num){
            return;
        }
        var sql = "select * from ui_user where id in("+num+")";
        U100Query(sql, function(er,re){
            callback(re);
        });
    },
    removeByValue:function(arr, val) {
        for (var i = 0; i < arr.length; i++) {
            if (arr[i] == val) {
                arr.splice(i, 1);break;
            }
        }
    },
    contains:function(arr, obj) {
        var i = arr.length;
        while (i--) {
            if (arr[i] === obj) {
                return true;
            }
        }
        return false;
    }
}




var arr=new Array();


app.get('/', function (req, res) {
    //res.sendfile(__dirname + '/views/');
    res.send('<h1>Welcome Realtime Server</h1>');
    console.log("开始监听.....")
});

io.sockets.on('connection', function (socket) {
    var newClock = new clock();
    socket.on('online', function(obj){
        var c = newClock.contains(arr,obj.uid);
        if(!c){
            arr.push(obj.uid);
        }
    });

    socket.on('outline', function(obj){
        newClock.removeByValue(arr,obj.uid);
    });

    deviceTime = setInterval(function(){
        var num = "";
        for(var k=0; k < arr.length; k++){
            if(k < arr.length -1){
                num += arr[k] + ',';
            }else{
                num += arr[k];
            }

        }
        newClock.showTime(num,function(re){
            for(var i=0; i < re.length; i++){
                socket.emit('send_'+re[i]['id'], { data: JSON.stringify( re[i] ) });
            }
        });

    },10000);

});
http.listen(8057, function(){
    console.log('listening on *:8057');
});
